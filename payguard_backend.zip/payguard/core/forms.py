from django import forms
from django.conf import settings
from django.core.exceptions import ValidationError
from .models import Repository
from .validators import validate_uploaded_file


class RepositoryForm(forms.ModelForm):
    class Meta:
        model = Repository
        fields = ["name", "url"]


class MultipleFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultipleFileField(forms.FileField):
    def __init__(self, *a, **kw):
        kw.setdefault("widget", MultipleFileInput())
        super().__init__(*a, **kw)

    def clean(self, data, initial=None):
        single = super().clean
        files = data if isinstance(data, (list, tuple)) else [data]
        return [single(f, initial) for f in files if f]


class UploadScanForm(forms.Form):
    files = MultipleFileField(help_text="YAML, Python, JSON, text or .env files. Max 1 MB each.")

    def clean_files(self):
        files = self.cleaned_data["files"]
        if not files:
            raise ValidationError("Choose at least one file.")
        if len(files) > settings.PAYGUARD_MAX_FILES:
            raise ValidationError(f"Upload at most {settings.PAYGUARD_MAX_FILES} files at a time.")
        errors, ok = [], []
        for f in files:
            try:
                ok.append(validate_uploaded_file(f))
            except ValidationError as e:
                errors.extend(e.messages)
        if errors:
            raise ValidationError(errors)
        return ok
