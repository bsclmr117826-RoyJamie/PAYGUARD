from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse

from core.models import Finding, Organization, Repository, Role, Scan, UserProfile
from core.security import mask_secret
from core.validators import safe_filename, validate_uploaded_file

SECRET_LINE = b'consumer_secret = "abcd1234efgh5678"\n'


def make_user(name, org, role):
    u = User.objects.create_user(name, password="pw-for-tests-123")
    UserProfile.objects.create(user=u, organization=org, role=role)
    return u


class MaskingTests(TestCase):
    def test_keeps_first_four_only(self):
        self.assertEqual(mask_secret("abcd1234efgh"), "abcd********")

    def test_short_values_fully_masked(self):
        self.assertEqual(mask_secret("abc"), "****")


class ValidatorTests(TestCase):
    def test_rejects_exe(self):
        with self.assertRaises(ValidationError):
            validate_uploaded_file(SimpleUploadedFile("evil.exe", b"MZ"))

    def test_rejects_binary_content(self):
        with self.assertRaises(ValidationError):
            validate_uploaded_file(SimpleUploadedFile("a.txt", b"ab\x00cd"))

    @override_settings(PAYGUARD_MAX_FILE_BYTES=10)
    def test_rejects_oversize(self):
        with self.assertRaises(ValidationError):
            validate_uploaded_file(SimpleUploadedFile("a.txt", b"x" * 11))

    def test_accepts_yaml(self):
        name, text = validate_uploaded_file(SimpleUploadedFile("ci.yml", b"on: push\n"))
        self.assertEqual((name, text), ("ci.yml", "on: push\n"))

    def test_filename_sanitised(self):
        self.assertEqual(safe_filename("../../etc/pass wd.txt"), "pass_wd.txt")


class AccessAndScanTests(TestCase):
    def setUp(self):
        call_command("seed_sitf", verbosity=0)
        self.org_a = Organization.objects.create(name="A")
        self.org_b = Organization.objects.create(name="B")
        self.dev = make_user("dev", self.org_a, Role.DEVELOPER)
        self.auditor = make_user("aud", self.org_a, Role.AUDITOR)
        self.other = make_user("other", self.org_b, Role.DEVELOPER)
        self.repo = Repository.objects.create(organization=self.org_a, name="wallet", created_by=self.dev)

    def upload(self, user, content=SECRET_LINE, name="settings.py"):
        self.client.force_login(user)
        return self.client.post(reverse("scan_upload", args=[self.repo.pk]),
                                {"files": SimpleUploadedFile(name, content)})

    def test_login_required(self):
        r = self.client.get(reverse("dashboard"))
        self.assertEqual(r.status_code, 302)

    def test_developer_scan_creates_masked_finding(self):
        r = self.upload(self.dev)
        self.assertEqual(r.status_code, 302)
        f = Finding.objects.get()
        self.assertEqual(f.masked_evidence, "abcd********")
        self.assertNotIn("1234efgh5678", f.masked_evidence)
        self.repo.refresh_from_db()
        self.assertEqual(self.repo.risk_score, 10)

    def test_auditor_cannot_upload(self):
        self.assertEqual(self.upload(self.auditor).status_code, 403)
        self.assertEqual(Scan.objects.count(), 0)

    def test_other_org_cannot_see_or_scan(self):
        self.upload(self.dev)
        scan = Scan.objects.get()
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(reverse("scan_detail", args=[scan.pk])).status_code, 404)
        self.assertEqual(self.upload(self.other).status_code, 404)

    def test_auditor_can_view_scan(self):
        self.upload(self.dev)
        scan = Scan.objects.get()
        self.client.force_login(self.auditor)
        self.assertEqual(self.client.get(reverse("scan_detail", args=[scan.pk])).status_code, 200)

    def test_bad_upload_rejected_with_no_scan(self):
        r = self.upload(self.dev, b"MZ", "evil.exe")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(Scan.objects.count(), 0)
