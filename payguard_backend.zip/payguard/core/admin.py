from django.contrib import admin
from .models import Organization, UserProfile, Pillar, SITFTechnique, Rule, Repository, Scan, Finding

for m in (Organization, UserProfile, Pillar, SITFTechnique, Rule, Repository, Scan, Finding):
    admin.site.register(m)
