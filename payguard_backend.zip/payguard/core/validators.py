"""Upload validation. Files are read into memory, checked, scanned and discarded; never executed or saved."""
import os
import re
from django.conf import settings
from django.core.exceptions import ValidationError


def safe_filename(name: str) -> str:
    base = os.path.basename(name or "").replace("\x00", "")
    return re.sub(r"[^A-Za-z0-9._-]", "_", base)[:120] or "unnamed"


def validate_uploaded_file(f):
    """Return (safe_name, text) or raise ValidationError."""
    name = safe_filename(f.name)
    ext = os.path.splitext(name)[1].lower()
    if ext not in settings.PAYGUARD_ALLOWED_EXTENSIONS:
        raise ValidationError(f"'{name}': file type '{ext or 'none'}' is not allowed.")
    if f.size > settings.PAYGUARD_MAX_FILE_BYTES:
        raise ValidationError(f"'{name}': larger than {settings.PAYGUARD_MAX_FILE_BYTES // 1024} KB.")
    data = f.read()
    if b"\x00" in data:
        raise ValidationError(f"'{name}': binary content is not allowed.")
    try:
        return name, data.decode("utf-8")
    except UnicodeDecodeError:
        raise ValidationError(f"'{name}': must be UTF-8 text.")
