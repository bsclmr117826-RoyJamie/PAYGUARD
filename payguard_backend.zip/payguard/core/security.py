def mask_secret(value: str) -> str:
    """Keep only the first 4 characters of a secret. Full values are never stored or shown."""
    value = (value or "").strip()
    if len(value) <= 4:
        return "****"
    return value[:4] + "*" * min(len(value) - 4, 8)
