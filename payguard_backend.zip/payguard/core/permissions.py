from functools import wraps
from django.core.exceptions import PermissionDenied
from django.contrib.auth.decorators import login_required
from .models import Repository, Scan


def get_role(user):
    return getattr(getattr(user, "profile", None), "role", None)


def role_required(*roles):
    """Allow only the listed roles (superusers always pass)."""
    def deco(view):
        @wraps(view)
        @login_required
        def wrapper(request, *a, **kw):
            if not request.user.is_superuser and get_role(request.user) not in roles:
                raise PermissionDenied
            return view(request, *a, **kw)
        return wrapper
    return deco


def repos_for(user):
    if user.is_superuser:
        return Repository.objects.all()
    org = getattr(getattr(user, "profile", None), "organization", None)
    return Repository.objects.filter(organization=org) if org else Repository.objects.none()


def scans_for(user):
    return Scan.objects.filter(repository__in=repos_for(user))
