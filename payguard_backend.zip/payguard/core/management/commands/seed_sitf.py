from django.core.management.base import BaseCommand
from core.models import Pillar, SITFTechnique, Rule

PILLARS = ["Endpoint / IDE", "VCS", "CI/CD", "Registry", "Production"]


class Command(BaseCommand):
    help = "Create the five SITF pillars, a starter technique per pillar and the demo rule VCS-001."

    def handle(self, *args, **opts):
        techs = {}
        for p in PILLARS:
            pillar, _ = Pillar.objects.get_or_create(name=p)
            techs[p], _ = SITFTechnique.objects.get_or_create(pillar=pillar, name=f"{p}: general weakness")
        Rule.objects.get_or_create(code="VCS-001", defaults={
            "description": "Hardcoded payment or API secret in source", "severity": "CRITICAL", "technique": techs["VCS"]})
        self.stdout.write(self.style.SUCCESS("SITF data seeded."))
