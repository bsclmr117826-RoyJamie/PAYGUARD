from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("repos/", views.repo_list, name="repo_list"),
    path("repos/new/", views.repo_create, name="repo_create"),
    path("repos/<int:repo_id>/scan/", views.scan_upload, name="scan_upload"),
    path("scans/<int:pk>/", views.scan_detail, name="scan_detail"),
]
