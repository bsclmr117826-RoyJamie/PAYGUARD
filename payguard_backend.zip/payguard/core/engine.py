"""Rule engine interface. Member 3 (Rule Engine Developer) replaces/extends this module.

Contract: scan_files(files) takes [(file_name, text), ...] and returns a list of dicts:
    {"rule_code": str, "file_path": str, "line_number": int, "evidence": str}
Evidence may contain the raw secret here; views mask it before saving.
"""
import re

DEMO_SECRET = re.compile(r"""(consumer_secret|consumer_key|passkey|api_key|secret)\s*[:=]\s*['"]([^'"]{6,})['"]""", re.I)


def scan_files(files):
    findings = []
    for name, text in files:
        for i, line in enumerate(text.splitlines(), 1):
            m = DEMO_SECRET.search(line)
            if m:
                findings.append({"rule_code": "VCS-001", "file_path": name, "line_number": i, "evidence": m.group(2)})
    return findings
