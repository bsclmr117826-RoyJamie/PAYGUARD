from django.conf import settings
from django.db import models

SEVERITY_WEIGHTS = {"CRITICAL": 10, "HIGH": 5, "MEDIUM": 2, "LOW": 1}


class Severity(models.TextChoices):
    CRITICAL = "CRITICAL", "Critical"
    HIGH = "HIGH", "High"
    MEDIUM = "MEDIUM", "Medium"
    LOW = "LOW", "Low"


class Role(models.TextChoices):
    DEVELOPER = "DEVELOPER", "Developer"
    AUDITOR = "AUDITOR", "Auditor"
    ADMIN = "ADMIN", "Admin"


class Organization(models.Model):
    name = models.CharField(max_length=120, unique=True)

    def __str__(self):
        return self.name


class UserProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    organization = models.ForeignKey(Organization, null=True, blank=True, on_delete=models.SET_NULL, related_name="members")
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.DEVELOPER)

    def __str__(self):
        return f"{self.user} ({self.role})"


class Pillar(models.Model):
    name = models.CharField(max_length=60, unique=True)

    def __str__(self):
        return self.name


class SITFTechnique(models.Model):
    pillar = models.ForeignKey(Pillar, on_delete=models.CASCADE, related_name="techniques")
    name = models.CharField(max_length=160)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name


class Rule(models.Model):
    code = models.CharField(max_length=20, unique=True)
    description = models.CharField(max_length=255)
    severity = models.CharField(max_length=10, choices=Severity.choices)
    technique = models.ForeignKey(SITFTechnique, on_delete=models.PROTECT, related_name="rules")
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.code


class Repository(models.Model):
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name="repositories")
    name = models.CharField(max_length=120)
    url = models.URLField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)
    risk_score = models.PositiveSmallIntegerField(default=0)

    class Meta:
        unique_together = ("organization", "name")
        ordering = ["name"]

    def __str__(self):
        return self.name


class Scan(models.Model):
    repository = models.ForeignKey(Repository, on_delete=models.CASCADE, related_name="scans")
    started_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL)
    started_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=12, default="COMPLETE")
    files_scanned = models.PositiveSmallIntegerField(default=0)
    total_findings = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-started_at"]

    def compute_risk_score(self):
        """sum(severity weight x count), capped at 100."""
        raw = sum(SEVERITY_WEIGHTS[f.severity] for f in self.findings.all())
        return min(100, raw)


class Finding(models.Model):
    scan = models.ForeignKey(Scan, on_delete=models.CASCADE, related_name="findings")
    rule = models.ForeignKey(Rule, on_delete=models.PROTECT, related_name="findings")
    file_path = models.CharField(max_length=255)
    line_number = models.PositiveIntegerField(default=0)
    severity = models.CharField(max_length=10, choices=Severity.choices)
    masked_evidence = models.CharField(max_length=120, blank=True)   # never store the full secret
    status = models.CharField(max_length=12, default="OPEN")

    class Meta:
        ordering = ["-id"]
