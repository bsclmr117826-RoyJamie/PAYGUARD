from django.contrib import messages
from django.db import transaction
from django.db.models import Count
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required

from . import engine
from .forms import RepositoryForm, UploadScanForm
from .models import Finding, Role, Rule, Scan
from .permissions import repos_for, role_required, scans_for
from .security import mask_secret


@login_required
def dashboard(request):
    scans = scans_for(request.user)
    by_sev = Finding.objects.filter(scan__in=scans).values("severity").annotate(n=Count("id"))
    ctx = {"repos": repos_for(request.user), "recent_scans": scans[:5], "by_severity": list(by_sev)}
    return render(request, "core/dashboard.html", ctx)


@login_required
def repo_list(request):
    return render(request, "core/repo_list.html", {"repos": repos_for(request.user)})


@role_required(Role.DEVELOPER, Role.ADMIN)
def repo_create(request):
    org = getattr(request.user.profile, "organization", None) if hasattr(request.user, "profile") else None
    form = RepositoryForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        if org is None:
            messages.error(request, "Your account has no organization yet. Ask an Admin.")
        else:
            repo = form.save(commit=False)
            repo.organization, repo.created_by = org, request.user
            repo.save()
            return redirect("repo_list")
    return render(request, "core/repo_form.html", {"form": form})


@role_required(Role.DEVELOPER, Role.ADMIN)
def scan_upload(request, repo_id):
    repo = get_object_or_404(repos_for(request.user), pk=repo_id)
    form = UploadScanForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        files = form.cleaned_data["files"]
        rules = {r.code: r for r in Rule.objects.filter(is_active=True)}
        with transaction.atomic():
            scan = Scan.objects.create(repository=repo, started_by=request.user, files_scanned=len(files))
            for hit in engine.scan_files(files):
                rule = rules.get(hit["rule_code"])
                if rule is None:
                    continue
                Finding.objects.create(
                    scan=scan, rule=rule, file_path=hit["file_path"], line_number=hit["line_number"],
                    severity=rule.severity, masked_evidence=mask_secret(hit["evidence"]),
                )
            scan.total_findings = scan.findings.count()
            scan.save(update_fields=["total_findings"])
            repo.risk_score = scan.compute_risk_score()
            repo.save(update_fields=["risk_score"])
        return redirect("scan_detail", pk=scan.pk)
    return render(request, "core/scan_upload.html", {"form": form, "repo": repo})


@login_required
def scan_detail(request, pk):
    scan = get_object_or_404(scans_for(request.user), pk=pk)
    return render(request, "core/scan_detail.html", {"scan": scan, "findings": scan.findings.select_related("rule__technique__pillar")})
