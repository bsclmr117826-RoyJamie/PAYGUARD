# PayGuard Backend (Member 2: Backend Lead)

Django 5 backend for PayGuard: models, login and roles, validated file upload, and secure settings.

## Run locally
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export DJANGO_DEBUG=1                                   # Windows: set DJANGO_DEBUG=1
python manage.py migrate
python manage.py seed_sitf                              # pillars, starter techniques, demo rule VCS-001
python manage.py createsuperuser
python manage.py runserver
python manage.py test core                              # 13 tests
```
In `/admin/`, create an **Organization**, then a **User Profile** for each user (organization + role).

## Roles
| Role | Can do |
|---|---|
| Developer | Add repositories, upload files and run scans, view own organization's scans |
| Auditor | View all scans and findings in own organization (read only) |
| Admin | Everything a Developer can do, plus user and rule management in `/admin/` |

## Where other members plug in
- **Member 3 (Rule Engine):** replace `core/engine.py` (`scan_files` contract in its docstring) and add `Rule` rows (admin or `seed_sitf`).
- **Member 4 (Dashboard):** use `Finding`, `Scan`, `Repository.risk_score`; charts go in `core/templates/core/dashboard.html`.
- **Member 5 (QA/DevOps):** `python manage.py test core` for CI; Bandit and pip-audit against this folder.

## Secure coding checklist (covered here)
- `DJANGO_SECRET_KEY` from environment; `DEBUG` off by default; the app refuses to start without a key.
- HTTPS, HSTS, secure and HttpOnly cookies, `X-Frame-Options: DENY`, nosniff when `DEBUG` is off.
- CSRF on all forms; Django ORM only (no raw SQL); template auto-escaping.
- Uploads: extension whitelist, 1 MB limit, 10 files max, no binary or non-UTF-8 content, sanitised names, processed in memory and never saved or executed.
- Secrets masked (first 4 characters) before anything is stored.
- Object-level access: users only reach repositories and scans from their own organization (others get 404); role checks return 403.
- Passwords: minimum 10 characters plus Django's common and numeric validators.

## Not yet done (future work)
Login rate limiting, export for Auditors, and the full rule set (Member 3).
