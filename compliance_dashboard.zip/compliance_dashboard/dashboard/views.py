from datetime import timedelta

from django.core.paginator import Paginator
from django.db.models import Count
from django.shortcuts import render
from django.utils import timezone

from . import charts
from .models import Finding

RANGES = [7, 30, 90]
SEV_LABELS = dict(Finding.Severity.choices)
PILLAR_LABELS = dict(Finding.Pillar.choices)


def _filters(request):
    try:
        days = int(request.GET.get("days", 30))
    except ValueError:
        days = 30
    days = days if days in RANGES else 30
    pillar = request.GET.get("pillar", "")
    severity = request.GET.get("severity", "")
    pillar = pillar if pillar in Finding.Pillar.values else ""
    severity = severity if severity in Finding.Severity.values else ""
    since = timezone.localdate() - timedelta(days=days - 1)
    qs = Finding.objects.filter(detected_at__gte=since)
    if pillar:
        qs = qs.filter(pillar=pillar)
    if severity:
        qs = qs.filter(severity=severity)
    ctx = {
        "days": days, "pillar": pillar, "severity": severity, "ranges": RANGES,
        "pillars": Finding.Pillar.choices, "severities": Finding.Severity.choices,
        "since": since,
    }
    return qs, ctx


def dashboard(request):
    qs, ctx = _filters(request)

    sev_counts = {r["severity"]: r["n"] for r in qs.values("severity").annotate(n=Count("id"))}

    matrix = {}
    for r in qs.values("pillar", "severity").annotate(n=Count("id")):
        matrix.setdefault(r["pillar"], {})[r["severity"]] = r["n"]

    per_day = {r["detected_at"]: r["n"] for r in qs.values("detected_at").annotate(n=Count("id"))}
    today = timezone.localdate()
    daily = [(ctx["since"] + timedelta(days=i), per_day.get(ctx["since"] + timedelta(days=i), 0))
             for i in range((today - ctx["since"]).days + 1)]

    top = [(r["rule_id"], r["title"], r["n"])
           for r in qs.values("rule_id", "title").annotate(n=Count("id")).order_by("-n", "rule_id")[:8]]

    total = qs.count()
    resolved = qs.filter(status=Finding.Status.RESOLVED).count()
    ctx.update({
        "kpis": {
            "total": total,
            "open": total - resolved,
            "critical_open": qs.filter(severity="critical", status=Finding.Status.OPEN).count(),
            "resolved_pct": round(100 * resolved / total) if total else 0,
        },
        "chart_severity": charts.severity_chart(sev_counts, SEV_LABELS),
        "chart_pillar": charts.pillar_chart(matrix, PILLAR_LABELS, SEV_LABELS),
        "chart_trend": charts.trend_chart(daily),
        "chart_rules": charts.top_rules_chart(top),
        "page": "dashboard",
    })
    return render(request, "dashboard/dashboard.html", ctx)


def findings(request):
    qs, ctx = _filters(request)
    status = request.GET.get("status", "")
    if status in Finding.Status.values:
        qs = qs.filter(status=status)
    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(title__icontains=q) | qs.filter(rule_id__icontains=q) | qs.filter(resource__icontains=q)
    page = Paginator(qs.order_by("-detected_at", "-id"), 20).get_page(request.GET.get("p"))
    params = request.GET.copy()
    params.pop("p", None)
    ctx.update({"page_obj": page, "status": status, "q": q, "statuses": Finding.Status.choices,
                "querystring": params.urlencode(), "page": "findings"})
    return render(request, "dashboard/findings.html", ctx)
