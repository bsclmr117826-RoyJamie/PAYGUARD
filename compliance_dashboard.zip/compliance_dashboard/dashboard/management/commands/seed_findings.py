import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from dashboard.models import Finding

RULES = [
    ("SEC-001", "Storage bucket allows public read", "security", "critical"),
    ("SEC-014", "Admin user without MFA", "security", "high"),
    ("SEC-022", "Access key older than 90 days", "security", "medium"),
    ("SEC-031", "TLS 1.0 still enabled", "security", "high"),
    ("REL-004", "Database has no automated backups", "reliability", "critical"),
    ("REL-009", "Single-zone deployment", "reliability", "high"),
    ("REL-017", "Health check missing on load balancer", "reliability", "medium"),
    ("PRF-003", "Instance CPU under 5% for 14 days", "performance", "low"),
    ("PRF-011", "No caching layer in front of API", "performance", "medium"),
    ("COST-002", "Unattached volumes", "cost", "low"),
    ("COST-008", "Idle load balancer", "cost", "medium"),
    ("OPS-005", "No alerting on error rate", "operations", "high"),
    ("OPS-012", "Resources missing owner tag", "operations", "low"),
]
WEIGHTS = [9, 6, 8, 4, 2, 4, 6, 7, 5, 8, 5, 4, 10]
SERVICES = ["payments", "auth", "search", "orders", "reports", "gateway", "ingest"]


class Command(BaseCommand):
    help = "Create demo findings spread over the last 90 days."

    def add_arguments(self, parser):
        parser.add_argument("--count", type=int, default=700)
        parser.add_argument("--clear", action="store_true")

    def handle(self, *args, **opts):
        rng = random.Random(42)
        if opts["clear"]:
            Finding.objects.all().delete()
        today = timezone.localdate()
        rows = []
        for _ in range(opts["count"]):
            rule_id, title, pillar, sev = rng.choices(RULES, weights=WEIGHTS)[0]
            age = int(rng.triangular(0, 90, 20))
            resolved = rng.random() < min(0.15 + age / 120, 0.85)
            rows.append(Finding(
                rule_id=rule_id, title=title, pillar=pillar, severity=sev,
                status="resolved" if resolved else "open",
                resource=f"{rng.choice(SERVICES)}-{rng.choice(['prod', 'stg', 'dev'])}-{rng.randint(1, 40):02d}",
                detected_at=today - timedelta(days=age),
            ))
        Finding.objects.bulk_create(rows)
        self.stdout.write(self.style.SUCCESS(f"Created {len(rows)} findings."))
