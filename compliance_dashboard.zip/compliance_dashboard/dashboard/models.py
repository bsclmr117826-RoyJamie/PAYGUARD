from django.db import models


class Finding(models.Model):
    class Severity(models.TextChoices):
        CRITICAL = "critical", "Critical"
        HIGH = "high", "High"
        MEDIUM = "medium", "Medium"
        LOW = "low", "Low"

    class Pillar(models.TextChoices):
        SECURITY = "security", "Security"
        RELIABILITY = "reliability", "Reliability"
        PERFORMANCE = "performance", "Performance"
        COST = "cost", "Cost"
        OPERATIONS = "operations", "Operations"

    class Status(models.TextChoices):
        OPEN = "open", "Open"
        RESOLVED = "resolved", "Resolved"

    rule_id = models.CharField(max_length=32, db_index=True)
    title = models.CharField(max_length=200)
    pillar = models.CharField(max_length=20, choices=Pillar.choices, db_index=True)
    severity = models.CharField(max_length=10, choices=Severity.choices, db_index=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.OPEN)
    resource = models.CharField(max_length=200)
    detected_at = models.DateField(db_index=True)

    class Meta:
        ordering = ["-detected_at", "-id"]

    def __str__(self):
        return f"{self.rule_id} on {self.resource}"
