from django.contrib import admin
from .models import Finding


@admin.register(Finding)
class FindingAdmin(admin.ModelAdmin):
    list_display = ("rule_id", "title", "pillar", "severity", "status", "resource", "detected_at")
    list_filter = ("severity", "pillar", "status")
    search_fields = ("rule_id", "title", "resource")
