"""Matplotlib charts rendered server-side to base64 PNGs.

Uses the object-oriented Figure API (no pyplot) so it is safe under
multi-threaded Django servers and needs no GUI backend.
"""
import base64
import io
from datetime import timedelta

import matplotlib.dates as mdates
from matplotlib.figure import Figure

INK = "#1F2A37"
MUTED = "#6B7686"
GRID = "#E3E7ED"
ACCENT = "#1F5F8B"
SEVERITY_COLORS = {"critical": "#B3261E", "high": "#E8590C", "medium": "#E2A400", "low": "#3C8DAD"}


def _encode(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=160, bbox_inches="tight", facecolor="white")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _style(ax, grid_axis="y"):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=9, length=0)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def _empty(w, h):
    fig = Figure(figsize=(w, h))
    ax = fig.subplots()
    ax.axis("off")
    ax.text(0.5, 0.5, "No findings in this range", ha="center", va="center", color=MUTED, fontsize=11)
    return _encode(fig)


def severity_chart(counts, labels):
    """counts: {severity: n}; donut with total in the middle."""
    order = [s for s in SEVERITY_COLORS if counts.get(s)]
    if not order:
        return _empty(5, 3.6)
    fig = Figure(figsize=(5, 3.6))
    ax = fig.subplots()
    vals = [counts[s] for s in order]
    ax.pie(vals, colors=[SEVERITY_COLORS[s] for s in order], startangle=90, counterclock=False,
           wedgeprops=dict(width=0.38, edgecolor="white", linewidth=2))
    ax.text(0, 0.06, f"{sum(vals):,}", ha="center", va="center", fontsize=22, fontweight="bold", color=INK)
    ax.text(0, -0.17, "findings", ha="center", va="center", fontsize=9, color=MUTED)
    ax.legend([f"{labels[s]}  {counts[s]:,}" for s in order], loc="center left",
              bbox_to_anchor=(1.0, 0.5), frameon=False, labelcolor=INK, fontsize=10)
    return _encode(fig)


def pillar_chart(matrix, pillar_labels, severity_labels):
    """matrix: {pillar: {severity: n}}; horizontal bars stacked by severity."""
    totals = {p: sum(v.values()) for p, v in matrix.items()}
    pillars = sorted(totals, key=totals.get)
    if not pillars:
        return _empty(6, 3.6)
    fig = Figure(figsize=(6, 3.6))
    ax = fig.subplots()
    left = [0] * len(pillars)
    for sev, color in SEVERITY_COLORS.items():
        vals = [matrix[p].get(sev, 0) for p in pillars]
        ax.barh([pillar_labels[p] for p in pillars], vals, left=left, color=color,
                label=severity_labels[sev], height=0.62, edgecolor="white", linewidth=1)
        left = [a + b for a, b in zip(left, vals)]
    for i, p in enumerate(pillars):
        ax.text(left[i] + max(left) * 0.015, i, f"{totals[p]:,}", va="center", fontsize=9, color=INK)
    ax.set_xlim(0, max(left) * 1.12)
    _style(ax, "x")
    ax.tick_params(axis="y", labelsize=10, colors=INK)
    ax.legend(ncol=4, frameon=False, fontsize=8.5, loc="upper center", bbox_to_anchor=(0.5, -0.1), labelcolor=MUTED)
    return _encode(fig)


def trend_chart(daily):
    """daily: list[(date, count)] with no gaps; bars plus a 7-day average line."""
    if not daily or not any(c for _, c in daily):
        return _empty(11, 3.4)
    dates = [d for d, _ in daily]
    counts = [c for _, c in daily]
    avg = [sum(counts[max(0, i - 6): i + 1]) / len(counts[max(0, i - 6): i + 1]) for i in range(len(counts))]
    fig = Figure(figsize=(11, 3.4))
    ax = fig.subplots()
    ax.bar(dates, counts, color="#C9DCEA", width=0.8, label="New findings per day")
    ax.plot(dates, avg, color=ACCENT, linewidth=2.4, label="7-day average")
    peak = max(range(len(counts)), key=counts.__getitem__)
    ax.annotate(f"Peak: {counts[peak]}", (dates[peak], counts[peak]), xytext=(0, 8),
                textcoords="offset points", ha="center", fontsize=9, color=INK)
    ax.set_ylim(0, max(counts) * 1.2)
    ax.set_xlim(dates[0] - timedelta(days=0.7), dates[-1] + timedelta(days=0.7))
    loc = mdates.AutoDateLocator(minticks=4, maxticks=8)
    ax.xaxis.set_major_locator(loc)
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(loc))
    _style(ax)
    ax.legend(frameon=False, fontsize=9, loc="upper left", labelcolor=MUTED)
    return _encode(fig)


def top_rules_chart(rows):
    """rows: list[(rule_id, title, count)] sorted desc."""
    if not rows:
        return _empty(6, 3.9)
    rows = rows[::-1]
    names = [f"{r}  {t if len(t) < 34 else t[:33] + '…'}" for r, t, _ in rows]
    vals = [c for _, _, c in rows]
    fig = Figure(figsize=(6, 3.9))
    ax = fig.subplots()
    ax.barh(names, vals, color=ACCENT, height=0.6)
    for i, v in enumerate(vals):
        ax.text(v + max(vals) * 0.015, i, f"{v:,}", va="center", fontsize=9, color=INK)
    ax.set_xlim(0, max(vals) * 1.12)
    _style(ax, "x")
    ax.tick_params(axis="y", labelsize=9, colors=INK)
    return _encode(fig)
