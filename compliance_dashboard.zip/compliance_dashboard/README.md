# Posture – Django + Matplotlib dashboard

Server-rendered dashboard (Django templates, Bootstrap 5) with four Matplotlib charts:
severity (donut), pillar (stacked bars), trend (daily bars + 7-day average) and top rules.

## Run it
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_findings          # demo data (--count 1000 --clear to reset)
python manage.py createsuperuser        # optional, for /admin
python manage.py runserver
```
Open http://127.0.0.1:8000/

## Layout
- `dashboard/models.py` – `Finding` (rule, pillar, severity, status, resource, date)
- `dashboard/charts.py` – chart functions returning base64 PNGs (Agg backend, thread-safe Figure API)
- `dashboard/views.py` – filters (period/pillar/severity) and ORM aggregation
- `dashboard/templates/dashboard/` – base, filters partial, dashboard, findings list
- `dashboard/management/commands/seed_findings.py` – demo data generator

## Use your own data
Replace the seed with your scanner output: create `Finding` rows (e.g. a management command that
reads your JSON/CSV). Add pillars or severities in `models.py` and in `SEVERITY_COLORS` in `charts.py`.
Each chart has a "Download PNG" link.
