# PayGuard Rule Engine (Rule Engine Developer's part)

Pure-Python scanner, SITF mapper and risk-score function. **No Django needed**, so it can be
tested on its own and plugged into the web layer later.

## Folder structure

```
payguard_rule_engine/
├── scanner/                  <- copy this folder into the team repo
│   ├── __init__.py           public functions: scan_text, scan_directory, calculate_risk_score ...
│   ├── __main__.py           quick check:  python -m scanner <folder>
│   ├── models.py             Finding and Rule data classes
│   ├── engine.py             runs the rules over text / files / folders
│   ├── sitf.py               SITF mapper (rule code -> pillar + technique)
│   ├── scoring.py            risk score, counts by severity/pillar, top rules
│   └── rules/
│       ├── __init__.py       rule registry (add new rules here)
│       ├── secrets.py        VCS-001, VCS-002, VCS-003
│       ├── cicd.py           CICD-001, CICD-002, CICD-003
│       ├── registry.py       REG-001
│       ├── production.py     PROD-001, PROD-002
│       └── endpoint.py       EP-001 (project-level)
├── tests/                    <- copy this folder too
├── pytest.ini
├── requirements.txt          PyYAML, pytest
└── README.md
```

## Run the tests

```
pip install -r requirements.txt
pytest
```

Expected: **32 passed**. Try it on any folder: `python -m scanner path/to/repo`

## The 10 rules (all five SITF pillars)

| Code | Pillar | Severity | Detects |
|---|---|---|---|
| EP-001 | Endpoint / IDE | Medium | `.env` exists but is not in `.gitignore` |
| VCS-001 | VCS | Critical | Hardcoded Daraja consumer key/secret |
| VCS-002 | VCS | Critical | Hardcoded Daraja passkey |
| VCS-003 | VCS | Critical | Hardcoded API token / secret key (incl. GitHub tokens) |
| CICD-001 | CI/CD | High | Action not pinned to a 40-char commit SHA |
| CICD-002 | CI/CD | High | `pull_request_target` that uses untrusted PR code |
| CICD-003 | CI/CD | High | `permissions: write-all` |
| REG-001 | Registry | Medium | Dependency not pinned with `==` |
| PROD-001 | Production | High | `DEBUG = True` |
| PROD-002 | Production | High | `http://` in a URL / callback / endpoint setting |

## How the Django side uses it

```python
from scanner import scan_text, calculate_risk_score

# for each uploaded file (after the Validator has accepted it):
findings = scan_text(uploaded_text, uploaded_filename)
for f in findings:
    Finding.objects.create(scan=scan, **f.to_dict())   # field names match the class diagram
score = calculate_risk_score(findings)
```

Secrets are masked inside the scanner: only the first 4 characters ever leave it.
The scanner only reads text; it never executes uploaded content.

## Decisions the team must confirm

1. **Risk score normalisation.** The proposal says "normalised to 0-100" with no method.
   `scoring.py` currently caps at 100. Change `calculate_risk_score` if the team prefers another way.
2. **SITF technique names** in `scanner/sitf.py` are descriptive placeholders. Replace them
   with the official SITF technique names/IDs.
3. **Trend chart.** The class diagram stores `riskScore` only on Repository, so past scores get
   overwritten. Add a `riskScore` field to Scan so the trend chart has data.
4. **Test cases.** The traceability matrix mentions TC-05 and TC-06, which are not defined yet.
   TC-01 to TC-03 are covered here; TC-04 (reject .exe upload) belongs to the Backend validator.

## Not built yet (planned rules from the proposal)

Secrets echoed in CI logs, cache key from untrusted input, known-vulnerable / typosquat packages
(pip-audit can cover this), and payment callback endpoint without validation.
